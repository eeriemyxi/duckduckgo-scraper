"""Easy to use asynchronous and synchronous DuckDuckGo search engine scraper."""

from .scraper import search, asearch
from ._dataclasses import Result